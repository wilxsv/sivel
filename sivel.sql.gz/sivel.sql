-- Adminer 4.2.1 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `archivos_persona`;
CREATE TABLE `archivos_persona` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nombre_archivo` text COLLATE utf8_bin NOT NULL,
  `path_archivo` text COLLATE utf8_bin NOT NULL,
  `id_persona` bigint(20) NOT NULL,
  `registro_archivo` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `path_archivo` (`path_archivo`(255)),
  KEY `id_persona` (`id_persona`),
  CONSTRAINT `archivos_persona_ibfk_1` FOREIGN KEY (`id_persona`) REFERENCES `persona` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;


DROP TABLE IF EXISTS `categoria`;
CREATE TABLE `categoria` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nombre_categoria` text COLLATE utf8_bin NOT NULL,
  `descripcion_categoria` text COLLATE utf8_bin,
  `id_categoria` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nombre_categoria` (`nombre_categoria`(255)),
  KEY `id_categoria` (`id_categoria`),
  CONSTRAINT `categoria_ibfk_3` FOREIGN KEY (`id_categoria`) REFERENCES `categoria` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO `categoria` (`id`, `nombre_categoria`, `descripcion_categoria`, `id_categoria`) VALUES
(11,	'Producto',	NULL,	NULL),
(12,	'Servicio',	NULL,	NULL);

DROP TABLE IF EXISTS `comentario`;
CREATE TABLE `comentario` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tipo` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `id_productoservicio` bigint(20) NOT NULL,
  `nombre_comentario` varchar(250) COLLATE utf8_bin NOT NULL,
  `email_comentario` varchar(150) COLLATE utf8_bin NOT NULL,
  `descripcion_comentario` longtext COLLATE utf8_bin NOT NULL,
  `registro_comentario` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;


DROP TABLE IF EXISTS `financiamiento`;
CREATE TABLE `financiamiento` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nombre_financiamiento` text COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nombre_financiamiento` (`nombre_financiamiento`(255))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO `financiamiento` (`id`, `nombre_financiamiento`) VALUES
(4,	'Pendiente por registrar');

DROP TABLE IF EXISTS `fos_group`;
CREATE TABLE `fos_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `roles` longtext COLLATE utf8_unicode_ci NOT NULL COMMENT '(DC2Type:array)',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_4B019DDB5E237E06` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


DROP TABLE IF EXISTS `fos_user`;
CREATE TABLE `fos_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `username_canonical` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email_canonical` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `enabled` tinyint(1) NOT NULL,
  `salt` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `last_login` datetime DEFAULT NULL,
  `locked` tinyint(1) NOT NULL,
  `expired` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL,
  `confirmation_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password_requested_at` datetime DEFAULT NULL,
  `roles` longtext COLLATE utf8_unicode_ci NOT NULL COMMENT '(DC2Type:array)',
  `credentials_expired` tinyint(1) NOT NULL,
  `credentials_expire_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_957A647992FC23A8` (`username_canonical`),
  UNIQUE KEY `UNIQ_957A6479A0D96FBF` (`email_canonical`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


DROP TABLE IF EXISTS `fos_user_user_group`;
CREATE TABLE `fos_user_user_group` (
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`user_id`,`group_id`),
  KEY `IDX_B3C77447A76ED395` (`user_id`),
  KEY `IDX_B3C77447FE54D947` (`group_id`),
  CONSTRAINT `FK_B3C77447A76ED395` FOREIGN KEY (`user_id`) REFERENCES `fos_user` (`id`),
  CONSTRAINT `FK_B3C77447FE54D947` FOREIGN KEY (`group_id`) REFERENCES `fos_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


DROP TABLE IF EXISTS `localidad`;
CREATE TABLE `localidad` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nombre_localidad` text COLLATE utf8_bin NOT NULL,
  `latitud_localidad` double NOT NULL,
  `longitud_localidad` double NOT NULL,
  `id_localidad` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nombre_localidad` (`nombre_localidad`(87)),
  KEY `id_localidad` (`id_localidad`),
  CONSTRAINT `localidad_ibfk_1` FOREIGN KEY (`id_localidad`) REFERENCES `localidad` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO `localidad` (`id`, `nombre_localidad`, `latitud_localidad`, `longitud_localidad`, `id_localidad`) VALUES
(2,	'San Salvador',	13.6929403,	-89.2181911,	NULL),
(3,	'Apopa',	13.8086742,	-89.1801225,	2),
(4,	'Cuscatlan',	13.8661957,	-89.0561532,	NULL),
(5,	'El Carmen',	13.7250533,	-88.9042582,	4),
(6,	'Perulapia',	13.7632951,	-89.0477956,	4),
(7,	'San Vicente',	13.6390979,	-88.7830612,	NULL),
(8,	'San Lorenzo',	13.7043211,	-88.8034854,	7),
(9,	'San Sebastian',	13.7232155,	-88.8190971,	7),
(10,	'Suchitoto',	13.932763,	-89.0251022,	4),
(11,	'San Antonio',	13.9523641,	-89.0850341,	10),
(12,	'Santa Fe',	13.933,	-89.025,	10),
(13,	'El Milagro',	13.932763,	-89.0251022,	10),
(14,	'Cantón El Caulote',	13.918215,	-89.0131532,	10),
(15,	'San José Palo Grande',	13.932763,	-89.0251022,	10),
(16,	'Cantón Los mangos',	13.7232155,	-88.8190971,	9),
(17,	'Ilopango',	13.6868163,	-89.1181849,	2),
(18,	'Animas',	13.766667,	-88.966667,	8),
(19,	'Las Lomas',	13.7632951,	-89.0477956,	6),
(20,	'Monte San Juan',	13.7600027,	-88.9497657,	5);

DROP TABLE IF EXISTS `periodo_produccion`;
CREATE TABLE `periodo_produccion` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `inicio_periodo` date NOT NULL,
  `fin_periodo` date NOT NULL,
  `id_producto` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_producto` (`id_producto`),
  CONSTRAINT `periodo_produccion_ibfk_1` FOREIGN KEY (`id_producto`) REFERENCES `producto` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;


DROP TABLE IF EXISTS `persona`;
CREATE TABLE `persona` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nombre_persona` text COLLATE utf8_bin NOT NULL,
  `dui_persona` text COLLATE utf8_bin NOT NULL,
  `nit_persona` text COLLATE utf8_bin NOT NULL,
  `nacimiento_persona` date NOT NULL DEFAULT '0000-00-00',
  `movil_persona` varchar(15) COLLATE utf8_bin NOT NULL DEFAULT '0',
  `telefono_persona` varchar(15) COLLATE utf8_bin NOT NULL DEFAULT '0',
  `correo_persona` text COLLATE utf8_bin NOT NULL,
  `sexo_persona` tinyint(4) NOT NULL DEFAULT '0',
  `ingreso_persona` date NOT NULL DEFAULT '0000-00-00',
  `id_localidad` bigint(20) NOT NULL,
  `latitud_persona` double NOT NULL,
  `longitud_persona` double NOT NULL,
  `direccion_persona` longtext COLLATE utf8_bin NOT NULL,
  `imagen_persona` longtext COLLATE utf8_bin NOT NULL,
  `observacion_persona` longtext COLLATE utf8_bin NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `dui_persona` (`dui_persona`(226)),
  UNIQUE KEY `nit_persona` (`nit_persona`(226)),
  KEY `id_localidad` (`id_localidad`),
  CONSTRAINT `persona_ibfk_1` FOREIGN KEY (`id_localidad`) REFERENCES `localidad` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO `persona` (`id`, `nombre_persona`, `dui_persona`, `nit_persona`, `nacimiento_persona`, `movil_persona`, `telefono_persona`, `correo_persona`, `sexo_persona`, `ingreso_persona`, `id_localidad`, `latitud_persona`, `longitud_persona`, `direccion_persona`, `imagen_persona`, `observacion_persona`, `registro`) VALUES
(70,	'Ricardo Abarca',	'0',	'0',	'2011-01-01',	'0',	'0',	'0@0.0',	1,	'2011-01-01',	2,	0,	0,	'0',	'assets/uploaded/a6382006fb63c268d8e4cc2015d25b4b.grafo',	'0',	'2016-07-03 22:23:38'),
(71,	'Javier Barrera',	'1',	'1',	'2011-01-01',	'1',	'1',	'0@0.01',	1,	'2011-01-01',	18,	0,	0,	'0',	'assets/uploaded/1c796837e15cc55d6ffea07c7fcfdbab.grafo',	'0',	'2016-07-03 22:25:07'),
(72,	'Juan Pablo Perez',	'2',	'2',	'2011-01-01',	'1',	'1',	'0@0.02',	1,	'2011-01-01',	2,	0,	0,	'0',	'assets/uploaded/855a3ae0733dc975d18215011f55a3bc.grafo',	'0',	'2016-07-03 22:25:41'),
(73,	'Maximiliano Cañas',	'3',	'3',	'2011-01-01',	'1',	'1',	'0@0.03',	1,	'2011-01-01',	18,	0,	0,	'0',	'assets/uploaded/1983aabb39b8a1e46db439812a956a84.grafo',	'0',	'2016-07-03 22:26:33'),
(74,	'Gregorio Acosta',	'4',	'4',	'2011-01-01',	'4',	'4',	'0@0.04',	1,	'2011-01-01',	15,	0,	0,	'0',	'assets/uploaded/persona.md5(uniqid()).grafo',	'0',	'2016-07-03 22:30:23'),
(75,	'Guadalupe Melgar',	'5',	'5',	'2011-01-01',	'4',	'4',	'5@0.04',	0,	'2011-01-01',	19,	0,	0,	'0',	'/tmp/php3gwyC2',	'0',	'2016-07-03 22:38:49'),
(76,	'Pedro Vasquez',	'6',	'6',	'2011-01-01',	'4',	'4',	'6@0.04',	1,	'2011-01-01',	11,	0,	0,	'0',	'assets/uploaded/persona.d41d8cd98f00b204e9800998ecf8427e.grafo',	'0',	'2016-07-03 22:40:51'),
(77,	'Mirna Lisabeth Martinez',	'7',	'7',	'2011-01-01',	'4',	'4',	'7@0.04',	1,	'2011-01-01',	16,	0,	0,	'0',	'assets/uploaded/persona.d41d8cd98f00b204e9800998ecf8427e.grafo',	'0',	'2016-07-03 22:41:36'),
(78,	'Colectivo El Caulote',	'8',	'8',	'2011-01-01',	'4',	'4',	'8@0.04',	1,	'2011-01-01',	14,	0,	0,	'0',	'assets/uploaded/persona.d41d8cd98f00b204e9800998ecf8427e.grafo',	'0',	'2016-07-03 22:42:46'),
(79,	'Juancho Paises',	'9',	'9',	'2011-01-01',	'4',	'4',	'9@0.04',	1,	'2011-01-01',	2,	0,	0,	'0',	'assets/uploaded/persona.d41d8cd98f00b204e9800998ecf8427e.grafo',	'0',	'2016-07-03 22:44:29'),
(80,	'Margarita Rodriguez',	'10',	'10',	'2011-01-01',	'4',	'4',	'10@0.04',	1,	'2011-01-01',	18,	0,	0,	'0',	'assets/uploaded/persona.d41d8cd98f00b204e9800998ecf8427e.grafo',	'0',	'2016-07-03 22:45:40'),
(82,	'Magdalena Corvera',	'11',	'11',	'2011-01-01',	'4',	'4',	'11@0.04',	0,	'2011-01-01',	18,	0,	0,	'0',	'assets/uploaded/persona.d41d8cd98f00b204e9800998ecf8427e.grafo',	'0',	'2016-07-03 22:46:28'),
(83,	'Gladis Santos',	'12',	'12',	'2011-01-01',	'4',	'4',	'12@0.04',	0,	'2011-01-01',	12,	0,	0,	'0',	'assets/uploaded/persona.d41d8cd98f00b204e9800998ecf8427e.grafo',	'0',	'2016-07-03 22:48:23'),
(84,	'Maria Elizabeth Lopez',	'13',	'13',	'2011-01-01',	'4',	'4',	'13@0.04',	0,	'2011-01-01',	12,	0,	0,	'0',	'assets/uploaded/persona.d41d8cd98f00b204e9800998ecf8427e.grafo',	'0',	'2016-07-03 22:49:19'),
(85,	'Javier Barrera',	'14',	'14',	'2011-01-01',	'4',	'4',	'14@0.04',	0,	'2011-01-01',	18,	0,	0,	'0',	'assets/uploaded/persona.d41d8cd98f00b204e9800998ecf8427e.grafo',	'0',	'2016-07-03 22:49:55'),
(86,	'Maria de Jesus Rivera',	'15',	'15',	'2011-01-01',	'4',	'4',	'15@0.04',	0,	'2011-01-01',	11,	0,	0,	'0',	'assets/uploaded/persona.d41d8cd98f00b204e9800998ecf8427e.grafo',	'0',	'2016-07-03 22:51:12'),
(87,	'Maximiliano Cañas',	'16',	'16',	'2011-01-01',	'4',	'4',	'16@0.04',	1,	'2011-01-01',	18,	0,	0,	'0',	'assets/uploaded/persona.d41d8cd98f00b204e9800998ecf8427e.grafo',	'0',	'2016-07-03 22:52:10'),
(88,	'Nicolas Hernandez',	'17',	'17',	'2011-01-01',	'4',	'4',	'17@0.04',	1,	'2011-01-01',	3,	0,	0,	'0',	'assets/uploaded/persona.d41d8cd98f00b204e9800998ecf8427e.grafo',	'0',	'2016-07-03 22:53:00'),
(89,	'Gabriela Escobar',	'18',	'18',	'2011-01-01',	'4',	'4',	'18@0.04',	1,	'2011-01-01',	9,	0,	0,	'0',	'assets/uploaded/persona.d41d8cd98f00b204e9800998ecf8427e.grafo',	'0',	'2016-07-03 22:53:40'),
(90,	'Teresa Abarca',	'19',	'19',	'2011-01-01',	'4',	'4',	'19@0.04',	0,	'2011-01-01',	17,	0,	0,	'0',	'assets/uploaded/persona.d41d8cd98f00b204e9800998ecf8427e.grafo',	'0',	'2016-07-03 22:54:28'),
(92,	'Vicenta Hernandez',	'20',	'20',	'2011-01-01',	'4',	'4',	'20@0.04',	0,	'2011-01-01',	20,	0,	0,	'0',	'assets/uploaded/persona.d41d8cd98f00b204e9800998ecf8427e.grafo',	'0',	'2016-07-03 22:55:30'),
(93,	'Magdalena Corvera',	'21',	'21',	'2011-01-01',	'4',	'4',	'21@0.04',	0,	'2011-01-01',	18,	0,	0,	'0',	'assets/uploaded/persona.d41d8cd98f00b204e9800998ecf8427e.grafo',	'0',	'2016-07-03 22:56:08'),
(94,	'Mariela Hernandez',	'22',	'22',	'2011-01-01',	'4',	'4',	'22@0.04',	0,	'2011-01-01',	10,	0,	0,	'0',	'assets/uploaded/persona.d41d8cd98f00b204e9800998ecf8427e.grafo',	'0',	'2016-07-03 22:57:03'),
(95,	'Vicenta Hernandez',	'23',	'23',	'2011-01-01',	'4',	'4',	'23@0.04',	0,	'2011-01-01',	20,	0,	0,	'0',	'assets/uploaded/persona.d41d8cd98f00b204e9800998ecf8427e.grafo',	'0',	'2016-07-03 22:57:36'),
(96,	'Cooperativa de Ilopango',	'24',	'24',	'2011-01-01',	'4',	'4',	'24@0.04',	0,	'2011-01-01',	17,	0,	0,	'0',	'assets/uploaded/persona.d41d8cd98f00b204e9800998ecf8427e.grafo',	'0',	'2016-07-03 22:58:04'),
(97,	'Mariela Hernandez',	'25',	'25',	'2011-01-01',	'4',	'4',	'25@0.04',	0,	'2011-01-01',	10,	0,	0,	'0',	'/tmp/phpTLMAGd',	'0',	'2016-07-03 22:59:23');

DROP TABLE IF EXISTS `producto`;
CREATE TABLE `producto` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `id_persona` bigint(20) NOT NULL,
  `id_categoria` bigint(20) NOT NULL,
  `id_financiamiento` bigint(20) NOT NULL,
  `nombre_producto` text COLLATE utf8_bin NOT NULL,
  `descripcion_producto` text COLLATE utf8_bin NOT NULL,
  `dimencion_producto` text COLLATE utf8_bin NOT NULL,
  `id_unidad` bigint(20) NOT NULL,
  `precio_producto` double NOT NULL DEFAULT '1.0001',
  `produccion_producto` bigint(20) NOT NULL DEFAULT '1',
  `visto_producto` bigint(20) NOT NULL DEFAULT '0',
  `img0_producto` text COLLATE utf8_bin,
  `img1_producto` text COLLATE utf8_bin,
  `img2_producto` text COLLATE utf8_bin,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `id_categoria` (`id_categoria`),
  KEY `id_financiamiento` (`id_financiamiento`),
  KEY `id_unidad` (`id_unidad`),
  KEY `id_persona` (`id_persona`),
  CONSTRAINT `producto_ibfk_1` FOREIGN KEY (`id_categoria`) REFERENCES `categoria` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `producto_ibfk_2` FOREIGN KEY (`id_financiamiento`) REFERENCES `financiamiento` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `producto_ibfk_3` FOREIGN KEY (`id_unidad`) REFERENCES `unidad_medida` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `producto_ibfk_5` FOREIGN KEY (`id_persona`) REFERENCES `persona` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO `producto` (`id`, `id_persona`, `id_categoria`, `id_financiamiento`, `nombre_producto`, `descripcion_producto`, `dimencion_producto`, `id_unidad`, `precio_producto`, `produccion_producto`, `visto_producto`, `img0_producto`, `img1_producto`, `img2_producto`, `registro`) VALUES
(5,	70,	11,	4,	'Miel de abeja',	'PRODUCTOS  TIO RICHAR',	'x',	11,	0,	200,	0,	NULL,	NULL,	NULL,	'2016-07-03 23:15:51'),
(6,	70,	11,	4,	'vino de jamaica',	'PRODUCTOS  TIO RICHAR',	'x',	11,	0,	50,	0,	NULL,	NULL,	NULL,	'2016-07-03 23:23:18'),
(7,	70,	11,	4,	'Flor de Jamaica seca',	'PRODUCTOS  TIO RICHAR',	'x',	13,	0,	50,	0,	NULL,	NULL,	NULL,	'2016-07-03 23:24:50'),
(8,	70,	11,	4,	'Flor de Jamaica seca',	'PRODUCTOS  TIO RICHAR',	'x',	13,	0,	50,	0,	NULL,	NULL,	NULL,	'2016-07-03 23:25:19'),
(9,	70,	11,	4,	'Café de Flor de jamaica',	'PRODUCTOS  TIO RICHAR',	'x',	13,	0,	50,	0,	NULL,	NULL,	NULL,	'2016-07-03 23:26:00'),
(10,	71,	11,	4,	'Miel de abeja',	'S/N',	'x',	11,	0,	200,	0,	NULL,	NULL,	NULL,	'2016-07-03 23:27:07'),
(11,	73,	11,	4,	'Horchata (tiste)',	'PRODISMAX',	'x',	13,	0,	100,	0,	NULL,	NULL,	NULL,	'2016-07-03 23:30:08'),
(12,	73,	11,	4,	'Chocolate',	'PRODISMAX',	'x',	13,	0,	100,	0,	NULL,	NULL,	NULL,	'2016-07-03 23:30:27'),
(13,	74,	11,	4,	'Café Molido Tradicional',	'JOYA HELADA',	'x',	13,	0,	50,	0,	NULL,	NULL,	NULL,	'2016-07-03 23:31:20'),
(14,	74,	11,	4,	'Café en grano tostado',	'JOYA HELADA',	'x',	13,	0,	25,	0,	NULL,	NULL,	NULL,	'2016-07-03 23:31:47'),
(15,	74,	11,	4,	'Café de Maiz tostado',	'JOYA HELADA',	'x',	13,	0,	25,	0,	NULL,	NULL,	NULL,	'2016-07-03 23:32:10'),
(16,	74,	11,	4,	'Café de Maicillo',	'JOYA HELADA',	'x',	13,	0,	5,	0,	NULL,	NULL,	NULL,	'2016-07-03 23:32:42'),
(17,	74,	11,	4,	'Tiste para Atol de maiz',	'JOYA HELADA',	'x',	13,	0,	25,	0,	NULL,	NULL,	NULL,	'2016-07-03 23:33:11'),
(18,	75,	11,	4,	'dulce tipicos artesanales',	'S/N',	'x',	13,	0,	50,	0,	NULL,	NULL,	NULL,	'2016-07-03 23:34:05'),
(19,	75,	11,	4,	'fruta deshidratada',	'S/N',	'x',	13,	0,	50,	0,	NULL,	NULL,	NULL,	'2016-07-03 23:34:33'),
(20,	75,	11,	4,	'Harina de maiz',	'S/N',	'x',	13,	0,	50,	0,	NULL,	NULL,	NULL,	'2016-07-03 23:34:48'),
(21,	76,	11,	4,	'vino de jamaica',	'SUCHIT TOTO',	'x',	11,	0,	50,	0,	NULL,	NULL,	NULL,	'2016-07-03 23:36:07'),
(22,	76,	11,	4,	'Flor de Jamaica seca',	'SUCHIT TOTO',	'x',	13,	0,	50,	0,	NULL,	NULL,	NULL,	'2016-07-03 23:36:48'),
(23,	76,	11,	4,	'jalea de jamaica',	'SUCHIT TOTO',	'x',	5,	0,	50,	0,	NULL,	NULL,	NULL,	'2016-07-03 23:37:07'),
(24,	77,	11,	4,	'Vino de flor Jamaica',	'Vinos LIZMARY',	'x',	11,	0,	25,	0,	NULL,	NULL,	NULL,	'2016-07-03 23:38:52'),
(25,	77,	11,	4,	'Vino de flor Jamaica',	'Vinos LIZMARY',	'x',	11,	0,	25,	0,	NULL,	NULL,	NULL,	'2016-07-03 23:39:11'),
(26,	77,	11,	4,	'Vino de papa',	'Vinos LIZMARY',	'x',	11,	0,	10,	0,	NULL,	NULL,	NULL,	'2016-07-03 23:39:43'),
(27,	77,	11,	4,	'vino de ciruela',	'Vinos LIZMARY',	'x',	11,	0,	10,	0,	NULL,	NULL,	NULL,	'2016-07-03 23:39:56'),
(28,	76,	11,	4,	'Vino de nance',	'SUCHIT TOTO',	'x',	11,	0,	50,	0,	NULL,	NULL,	NULL,	'2016-07-03 23:41:22'),
(29,	78,	11,	4,	'chorizos vegetarianos',	'DELICRIOLLO',	'x',	13,	0,	50,	0,	NULL,	NULL,	NULL,	'2016-07-03 23:42:01'),
(30,	78,	11,	4,	'chorizos de res',	'DELICRIOLLO',	'x',	13,	0,	50,	0,	NULL,	NULL,	NULL,	'2016-07-03 23:42:18'),
(31,	78,	11,	4,	'chorizos picantes',	'DELICRIOLLO',	'x',	13,	0,	50,	0,	NULL,	NULL,	NULL,	'2016-07-03 23:42:33'),
(32,	78,	11,	4,	'chorizos argentino',	'DELICRIOLLO',	'x',	13,	0,	50,	0,	NULL,	NULL,	NULL,	'2016-07-03 23:42:47'),
(33,	78,	11,	4,	'butifarras',	'DELICRIOLLO',	'x',	13,	0,	50,	0,	NULL,	NULL,	NULL,	'2016-07-03 23:43:03'),
(34,	79,	11,	4,	'Mermeladas fruta temporada',	'S/N',	'x',	9,	0,	100,	0,	NULL,	NULL,	NULL,	'2016-07-03 23:43:58'),
(35,	79,	11,	4,	'mermeladas gurmet',	'S/N',	'x',	9,	0,	100,	0,	NULL,	NULL,	NULL,	'2016-07-03 23:44:16'),
(36,	80,	11,	4,	'Gallina india',	'S/N',	'x',	9,	0,	10,	0,	NULL,	NULL,	NULL,	'2016-07-03 23:44:46'),
(37,	80,	11,	4,	'Pollo indio',	'S/N',	'x',	9,	0,	10,	0,	NULL,	NULL,	NULL,	'2016-07-03 23:45:01'),
(38,	80,	11,	4,	'Gallina india',	'S/N',	'x',	14,	0,	10,	0,	NULL,	NULL,	NULL,	'2016-07-03 23:45:28'),
(39,	80,	11,	4,	'Pollo indio',	'S/N',	'x',	14,	0,	10,	0,	NULL,	NULL,	NULL,	'2016-07-03 23:45:46'),
(40,	83,	11,	4,	'fruta de temporada',	'S/N',	'x',	14,	0,	-1,	0,	NULL,	NULL,	NULL,	'2016-07-03 23:46:28'),
(41,	83,	11,	4,	'verdura de temporada',	'S/N',	'x',	14,	0,	-1,	0,	NULL,	NULL,	NULL,	'2016-07-03 23:46:47'),
(42,	84,	11,	4,	'mani en conserva',	'S/N',	'x',	6,	0,	50,	0,	NULL,	NULL,	NULL,	'2016-07-03 23:47:35'),
(43,	85,	11,	4,	'Pollo de  granja',	'S/N',	'x',	13,	0,	100,	0,	NULL,	NULL,	NULL,	'2016-07-03 23:48:18'),
(44,	86,	11,	4,	'carne de conejo',	'S/N',	'x',	13,	0,	5,	0,	NULL,	NULL,	NULL,	'2016-07-03 23:48:59'),
(45,	86,	11,	4,	'esencias naturales',	'Esencias Mi Tierra',	'x',	10,	0,	500,	0,	NULL,	NULL,	NULL,	'2016-07-03 23:49:40'),
(46,	86,	11,	4,	'huevos de gallina',	'S/N',	'x',	14,	0,	300,	0,	NULL,	NULL,	NULL,	'2016-07-03 23:50:02'),
(47,	86,	11,	4,	'conejo en pie',	'S/N',	'x',	14,	0,	-1,	0,	NULL,	NULL,	NULL,	'2016-07-03 23:50:44'),
(48,	73,	11,	4,	'Crema',	'PRODISMAX',	'x',	10,	0,	50,	0,	NULL,	NULL,	NULL,	'2016-07-03 23:51:30'),
(49,	73,	11,	4,	'Queso duro',	'PRODISMAX',	'x',	13,	0,	50,	0,	NULL,	NULL,	NULL,	'2016-07-03 23:51:53'),
(50,	73,	11,	4,	'Queso fresco',	'PRODISMAX',	'x',	13,	0,	50,	0,	NULL,	NULL,	NULL,	'2016-07-03 23:52:12'),
(51,	88,	11,	4,	'Crema',	'S/N',	'x',	10,	0,	20,	0,	NULL,	NULL,	NULL,	'2016-07-03 23:53:04'),
(52,	88,	11,	4,	'Queso fresco',	'S/N',	'x',	13,	0,	20,	0,	NULL,	NULL,	NULL,	'2016-07-03 23:53:25'),
(53,	88,	11,	4,	'requeson',	'S/N',	'x',	13,	0,	20,	0,	NULL,	NULL,	NULL,	'2016-07-03 23:53:38'),
(54,	89,	11,	4,	'Productos textil  artesanal',	'S/N',	'x',	14,	0,	-1,	0,	NULL,	NULL,	NULL,	'2016-07-03 23:54:06'),
(55,	89,	11,	4,	'Alhuaiste',	'S/N',	'x',	13,	0,	25,	0,	NULL,	NULL,	NULL,	'2016-07-03 23:54:26'),
(56,	89,	11,	4,	'Dulce de panela molido',	'S/N',	'x',	13,	0,	25,	0,	NULL,	NULL,	NULL,	'2016-07-03 23:54:42'),
(57,	90,	11,	4,	'tortas de pan',	'S/N',	'x',	13,	0,	25,	0,	NULL,	NULL,	NULL,	'2016-07-03 23:55:01'),
(58,	90,	11,	4,	'quesadillas',	'S/N',	'x',	13,	0,	25,	0,	NULL,	NULL,	NULL,	'2016-07-03 23:55:20'),
(59,	92,	11,	4,	'salpores',	'S/N',	'x',	13,	0,	25,	0,	NULL,	NULL,	NULL,	'2016-07-03 23:55:47'),
(60,	93,	11,	4,	'salpores',	'S/N',	'x',	13,	0,	25,	0,	NULL,	NULL,	NULL,	'2016-07-03 23:56:08'),
(61,	94,	11,	4,	'semita',	'S/N',	'x',	13,	0,	25,	0,	NULL,	NULL,	NULL,	'2016-07-03 23:56:26'),
(62,	95,	11,	4,	'marquesote',	'S/N',	'x',	13,	0,	25,	0,	NULL,	NULL,	NULL,	'2016-07-03 23:56:44'),
(63,	96,	11,	4,	'Tilapia',	'Cooperativa de Ilopango \r\n',	'x',	13,	0,	25,	0,	NULL,	NULL,	NULL,	'2016-07-03 23:57:02'),
(64,	97,	11,	4,	'plantas hornamentales',	'Vivero mujers Vive',	'x',	14,	0,	-1,	0,	NULL,	NULL,	NULL,	'2016-07-03 23:58:41'),
(65,	97,	11,	4,	'plantas medicinal',	'Vivero mujers Vive',	'x',	14,	0,	-1,	0,	NULL,	NULL,	NULL,	'2016-07-03 23:58:56'),
(66,	97,	11,	4,	'abonos organicos',	'Vivero mujers Vive',	'x',	14,	0,	-1,	0,	NULL,	NULL,	NULL,	'2016-07-03 23:59:08'),
(67,	97,	11,	4,	'macetas de alambre',	'Vivero mujers Vive',	'x',	14,	0,	-1,	0,	NULL,	NULL,	NULL,	'2016-07-03 23:59:25');

DROP TABLE IF EXISTS `servicio`;
CREATE TABLE `servicio` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `id_persona` bigint(20) NOT NULL,
  `id_categoria` bigint(20) NOT NULL,
  `id_financiamiento` bigint(20) NOT NULL,
  `nombre_servicio` text COLLATE utf8_bin NOT NULL,
  `descripcion_servicio` text COLLATE utf8_bin NOT NULL,
  `precio_servicio` double NOT NULL DEFAULT '1.0001',
  `visto_servicio` bigint(20) NOT NULL DEFAULT '0',
  `img0_servicio` text COLLATE utf8_bin,
  `img1_servicio` text COLLATE utf8_bin,
  `img2_servicio` text COLLATE utf8_bin,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `id_categoria` (`id_categoria`),
  KEY `id_financiamiento` (`id_financiamiento`),
  KEY `id_persona` (`id_persona`),
  CONSTRAINT `servicio_ibfk_1` FOREIGN KEY (`id_categoria`) REFERENCES `categoria` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `servicio_ibfk_2` FOREIGN KEY (`id_financiamiento`) REFERENCES `financiamiento` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `servicio_ibfk_4` FOREIGN KEY (`id_persona`) REFERENCES `persona` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;


DROP TABLE IF EXISTS `unidad_medida`;
CREATE TABLE `unidad_medida` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nombre_unidad` text COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO `unidad_medida` (`id`, `nombre_unidad`) VALUES
(4,	'Bolsa'),
(5,	'Bolsa 12 onz.\r\n'),
(6,	'Bolsa 4 onz.\r\n'),
(7,	'Bote 30 capsulas'),
(8,	'Bote de  400ml\r\n'),
(9,	'Bote de  8 onz'),
(10,	'Botella de 500 ml.'),
(11,	'Botella de 750 ml.\r\n'),
(12,	'Frasco de 8 onzas '),
(13,	'Libra\r\n'),
(14,	'Unidad');

-- 2017-06-22 05:54:01
